@extends('layouts.app')
@section('content')
<div class="container">
    <ul class="list-group">
            <li class="list-group-item active">Subscribers<a class="float-right btn btn-success" href="{{route('readers.create')}}">Subscribe</a>
            </li>
        @if(count($readers) > 0)
        @foreach($readers as $reader)
            <li class="list-group-item"> {{ $reader->name }} | {{ $reader->email }}</li>
        @endforeach
        @else
            <li class="list-group-item"> There are no available followers !</li>
        @endif
    </ul>
</div>
@endsection
