@extends('layouts.app')
@section('content')
    <div class="container">
        
        <ul class="list-group">
        <li class="list-group-item"><a href="{{ route('author.create') }}" class="btn btn-info">Register</a></li>
            @if(count($authors) > 0)
                    @foreach($authors as $author)
                        <li class="list-group-item"> {{ $author->name}}  |  {{ $author->email}} </li>
                    @endforeach
            @else
            <li class="list-group-item"> There are no available authors !</li>
            @endif
        </ul>
    </div>
@endsection