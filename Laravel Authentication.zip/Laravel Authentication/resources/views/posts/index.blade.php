@extends('layouts.app')
@section('content')
<div class="container">
    <ul class="list-group">
        <li class="list-group-item">
        <a class="btn btn-primary" href="{{route('posts.create')}}">Create Post</a>
        <a class="float-right btn btn-secondary" href="{{route('readers.index')}}">Subscribe to Our Posts</a>
        </li>
        @if(count($posts) > 0)
        @foreach($posts as $post)
        <li class="list-group-item"> {{ $post->title }} | {{$post->body}} | <br><small>Created by : {{$post->author->name}}</small>
            <span>
                <div class="container">
                    <hr/>
                    <form action="{{ route('comments.store' ) }}">
                        <input class="form-control" type="text" name="comment" placeholder="Add Your Comment Here...." />
                        <br><button type="submit" class="btn btn-sm btn-success">Save</button>
                    </form>
                </div>
            </span>
        </li>
        @endforeach
        @else
        <li class="list-group-item"> There are no available posts !</li>
        @endif
    </ul>
</div>
@endsection
