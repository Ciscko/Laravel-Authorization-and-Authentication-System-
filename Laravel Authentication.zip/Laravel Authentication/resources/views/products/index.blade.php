@extends('layouts.app')

@section('content')
<x-products-nav/>

<div class="container">
    <h3>All Products</h3>
    @if(count($products) > 0)
    <ol class="list-group list-group-flush">
        @foreach($products as $product)
        <li class="list-group-item">
        <img style="width:50px; height:40px;"
         src="{{asset($product->image)}}"> {{ $product->name }}
        <span class="float-right">
         <a href="{{ route('admin.products.edit', ['product' => $product->id]) }}"
          class="btn btn-sm btn-primary"> Edit </a> <a class="btn btn-sm btn-success"
           href="{{route('admin.products.view', ['product' => $product->id])}}"> View </a>
            <button class="btn btn-sm btn-danger" onclick="document.querySelector('.delete-form').submit();"> Delete </button></span></li>
        <form class="delete-form" action="{{route('admin.products.delete', ['id' => $product->id ])}}" method="post">
        @csrf
        @method('delete')
</form>
        @endforeach
       {{--  @if(($products->links()))
            <li class="list-group-item"> {{ $products->links() }}</li>
        @endif --}}
    </ol>
    @else
    <p> No products are available for now ! </p>
    @endif
</div>

@endsection























{{-- <x-navbar-component style="color:green; text-align:center; margin:10px; background:pink; font-size:20px; padding:10px;" message="Navbar">
    <x-slot name="title">
       Title: {{ $component->title}}
</x-slot>
</x-navbar-component> --}}

{{-- @date(time()) --}}

{{-- @section('sidebar')
    @parent
    <x-button style="color:white; border-radius:2px; border:solid red 3px; padding:5px; background:green; min-width:30px; min-height:20px;"  text="Click Me"/>
@endsection --}}
{{-- @guest
    @section('content')
        <ol>
            @foreach( $products as $product )
                
                <li>{{ $product->name }}</li>

@endforeach
</ol>
@endsection
@endauth --}}

{{-- @production
    <p>This is displayed in production only</p>
@endproduction --}}

{{-- @greet() --}}
{{--
<script>
    function show() {
        let data = @json($products);
        let data2 = '';
        console.log(data2);
    }

</script> --}}
