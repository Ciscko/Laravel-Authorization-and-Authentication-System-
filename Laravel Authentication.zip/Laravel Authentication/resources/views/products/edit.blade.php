@extends('layouts.app')


@section('content')
<x-products-nav/>
<div class="container">
    <h3> Edit Product </h3>
     <form action="{{ route('admin.products.update', ['id' => $product->id]) }}" method="post" enctype="multipart/form-data">
        @csrf
        @method('put')
        <div>
            <input type="text" name="name" class="form-control" value="{{$product->name}}"/>
        </div>
        <div>
         <div>
            <label for="image">Image</label>
            <input type="file" name='image' class="form-control"/>
            @error('image')
                <div class="alert alert-danger">{{ $message }}</div>
            @enderror
        </div>
        <br>
            <input type="submit" value="Update" class="btn btn-info"/>
        </div>
    </form>
</div>
   
@endsection