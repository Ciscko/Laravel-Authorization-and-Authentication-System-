@extends('layouts.app')


@section('content')
<x-products-nav/>
<div class="container">
    <h3> Create Product</h3>
     <form action="{{ route('admin.products.store') }}" method="post" enctype="multipart/form-data">
        @csrf
        @if($errors->any())
        
        @endif
        <div>
            <input type="text" name="name" class="form-control" />
          
            @error('name')
                <div class="alert alert-danger">{{ $message }}</div>
            @enderror
        </div>
        <div>
            <label for="image">Image</label>
            <input type="file" name='image' class="form-control"/>
            @error('image')
                <div class="alert alert-danger">{{ $message }}</div>
            @enderror
        </div>
        <div>
        <br>
            <input type="submit" value="Submit" class="btn btn-success"/>
        </div>
        <div>
            @foreach($errors->all() as $error)
                <p class="alert danger">{{ $error }}</p>
            @endforeach
        </div>
    </form>
</div>
   
@endsection