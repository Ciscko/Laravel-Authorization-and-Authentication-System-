<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <ul class="list-group">
        <li class="list-group-item"><a href="<?php echo e(route('author.create')); ?>" class="btn btn-info">Register</a></li>
            <?php if(count($authors) > 0): ?>
                    <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item"> <?php echo e($author->name); ?>  |  <?php echo e($author->email); ?> </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <li class="list-group-item"> There are no available authors !</li>
            <?php endif; ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/Mbucha.co.ke/public_html/Laralive/resources/views/authors/index.blade.php ENDPATH**/ ?>