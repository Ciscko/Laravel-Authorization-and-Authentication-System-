<div>
    <!-- Well begun is half done. - Aristotle -->
    <button <?php echo e($attributes); ?> onclick="show()"> <?php echo e($text); ?></button>
</div>


<?php /**PATH /var/www/Mbucha.co.ke/public_html/Laralive/resources/views/components/button.blade.php ENDPATH**/ ?>