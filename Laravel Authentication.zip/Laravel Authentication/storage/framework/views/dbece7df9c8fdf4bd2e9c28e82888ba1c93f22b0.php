<?php $__env->startSection('content'); ?>
<div class="container">
    <ul class="list-group">
        <li class="list-group-item">
        <a class="btn btn-primary" href="<?php echo e(route('posts.create')); ?>">Create Post</a>
        <a class="float-right btn btn-secondary" href="<?php echo e(route('readers.index')); ?>">Subscribe to Our Posts</a>
        </li>
        <?php if(count($posts) > 0): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item"> <?php echo e($post->title); ?> | <?php echo e($post->body); ?> | <br><small>Created by : <?php echo e($post->author->name); ?></small>
            <span>
                <div class="container">
                    <hr/>
                    <form action="<?php echo e(route('comments.store' )); ?>">
                        <input class="form-control" type="text" name="comment" placeholder="Add Your Comment Here...." />
                        <br><button type="submit" class="btn btn-sm btn-success">Save</button>
                    </form>
                </div>
            </span>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <li class="list-group-item"> There are no available posts !</li>
        <?php endif; ?>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/Mbucha.co.ke/public_html/Laralive/resources/views/posts/index.blade.php ENDPATH**/ ?>