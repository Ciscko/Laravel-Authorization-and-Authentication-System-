<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/app.css')); ?>"/>
</head>
<body>
<div id="main" class="container">
</div>
   <script src="<?php echo e(mix('/js/app.js')); ?>"></script>
</body>
</html><?php /**PATH /var/www/Mbucha.co.ke/public_html/Laralive/resources/views/layout.blade.php ENDPATH**/ ?>