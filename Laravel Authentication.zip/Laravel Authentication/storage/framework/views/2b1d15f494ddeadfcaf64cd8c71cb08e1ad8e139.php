<?php $__env->startSection('content'); ?>
<div class="container">
    <ul class="list-group">
        <li class="list-group-item active">Subscribers<a class="float-right btn btn-success" href="<?php echo e(route('readers.create')); ?>">Subscribe</a>
        </li>
        <?php if(count($readers) > 0): ?>
        <?php $__currentLoopData = $readers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item"> <?php echo e($reader->name); ?> | <?php echo e($reader->email); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <li class="list-group-item"> There are no available followers !</li>
        <?php endif; ?>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/Mbucha.co.ke/public_html/Laralive/resources/views/readers/index.blade.php ENDPATH**/ ?>