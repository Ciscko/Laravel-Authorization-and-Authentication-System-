<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $fillable = ['title', 'body' , 'slug', 'author_id'];
    protected $hidden = ['created_at', 'updated_at'];

    public function author(){
        return $this->belongsTo('App\Author');
    }

    public function comments(){
        return $this->hasMany('App\Comment');
    }

    public function themes(){
        return $this->belongsToMany('App\Theme');
    }
    
}
