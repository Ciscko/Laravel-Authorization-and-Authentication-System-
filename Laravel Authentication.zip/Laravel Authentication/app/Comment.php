<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    protected $fillable = ['body', 'post', 'reader'];
    protected $hidden = ['created_at', 'updated_at'];

    public function reader(){
        return $this->belongsTo('App\Reader');
    }

    public function post(){
        return $this->belongsTo('App\Post');
    }

}


