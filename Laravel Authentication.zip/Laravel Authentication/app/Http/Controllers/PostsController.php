<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Post;
use Auth;
class PostsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct(){
        //$this->middleware('auth:author');
    }

    public function index()
    {
        //DB::select('insert into posts (title, body, slug ) values (?, ?, ? )', ["The gospel", "This is the body of the gospel..", "You must believe"]);
        //DB::select('update posts set body=? where id=?', ['This is the body of post two', 2]);
        //DB::select('update posts set title = ? where id = ? ', ['The Gospel of our Lord Jesus Christ', 2]);
        //DB::select('delete from posts where id = ? ', [1]);
        //DB::select('delete from posts where id  = 3');
        //DB::insert('insert into posts (title, body, slug) values (?, ?, ?)', ['The Meaning of Life', 'All things work together for good', '#lifeIsShortAndPrecious']);
         $posts = DB::select('select * from posts');
       /*  $posts = array();
        $posts =  DB::transaction(function(){
          DB::table('posts')->get();
        }); */
         /* Post::create(
            [
                'title' => 'The Message of Love',
                'body' => 'The all time work of Jesus Christ',
                'slug' => '#lovePeaceGentlenessForbearancePatience'
            ]
        ); */
       /*  [
            'title' => 'Love',
            'body' => 'The Genesis of love',
            'slug' => '#loveAndPeace'
        ] */
        /*  */
        $posts = Post::all();
        return view('posts.index', ['posts' => $posts]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('posts.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->middleware('auth:author');
        $rules = [
            'title' => 'required|min:4|string|max:100',
            'slug' =>'required|string',
            'body' => 'required|min:5|string'
        ];
        $request->validate($rules);
        Post::create([
            'title' => $request->title,
            'slug' => $request->slug,
            'body' => $request->body,
            'author_id' => Auth::user()->id
        ]);
        return redirect(route('posts.index'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return 'show';
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return 'edit';
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
