<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\ProductRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use App\Products;
use App\Http\Resources\Products as ProductsResource;


class ProductsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
     public function __construct(){
            //$this->middleware('auth:admin');
     }
    public function index(Request $request)
    {
        //if(Gate::authorize('products')){
            if(true){
            //$products = DB::table('products')->paginate(2);
            //$products = Products::paginate(1);
            //$products->appends(['sort' => 'name'])->links();
            //$products = Products::all();
            //dd($products);
           // $products = DB::table('products')->select('name')->distinct()->get();
           //$products = DB::table('products')->select(DB::raw('count(*) as total, id'))->groupBy('id')->get();
            //$products = DB::table('products')->get()->pluck('name')->chunk(2);
            //$aggregate = DB::table('products')->max('id');
            //return($products->name);
            //dd($aggregate);
             /* DB::table('products')
            ->insert([
                ['name' => 'Moreschi Yello', 'image' => 'imageurl', 'category' => 1],
                ['name' => 'Jumbos', 'image' => 'anotherurl', 'category' => 2]
                ]); */
                //DB::table('products')->where('category', 22)->decrement('category', 10);
                //$products = DB::table('products')->where('name', 'like','J%' )->get();
                //return $products;
                $product = new Products;
                $product->name = 'Kiatu';
                $product->image = 'urlsnimob';
                $product->category = 2;
                //$product->save();
                //$products = Products::where('id', '<', 80)->paginate(2);
                $paginate = 2;
                $search = '';
                if($request->query('per_page') != null){
                    $paginate = $request->query('per_page');
                }
                $products = Products::paginate($paginate);
                if($request->query('search') != null || $request->query('search')!=''){
                    $search = $request->query('search');
                    $products = Products::where('name','like' ,'%'.$search.'%')->orWhere('image', 'like','%'.$search.'%')->paginate($paginate);
                }
                

                //$product['mystuff'] = $perpage;
                /* $products = $products->reject(function($user){
                    return $user->id > 8 ;
                })->map(function($user){
                    return $user->name;
                }); */
               //$products = $products->contains(Products::find(2));
               //return $products->toJson(JSON_PRETTY_PRINT);
               // $products = $products->diff(Products::whereIn('id', [1, 3, 4])->get());
                return(new ProductsResource($products));
            //return view('products.index', ['products' => $products, 'user' => Auth::user() ]);
        }else{
            return redirect()->back();
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $admin = auth('admin')->user();
        $this->authorizeForUser( $admin, 'create' , Products::class); 
        return view('products.create'); 
    }
    /**
     * Store a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      /*   //Storage::put('mytext.txt', 'I love programming, May Jehova help me make a decent living out of it!');
        if($request->hasFile('image')){
            $ext = $request->image->extension();
           //$filepath = $request->file('image')->storeAs('images', time().'.'.$ext);
           $filepath = Storage::putFileAs('images', $request->file('image'), $request->file('image')->getClientOriginalName());
           //dd($filepath);
           //Storage::get($filepath);
           ///dd(Storage::url($filepath).'-----'.Storage::size($filepath));
            Storage::delete($filepath);
            //Storage::copy('local')
            return Storage::download($filepath);
        } */
       
        /*   $rules = [
            'name' => 'required|min:4|max:10',
            'image' => 'required|'
        ];
       if($request->hasFile('image')){
           $ext = $request->image->extension();
          $filepath = $request->file('image')->storeAs('images', time().'.'.$ext);
          dd($filepath);
          
       } */
       // $request->validate();
       //if($request->hasFile('image')){
           $rules = [
               'name' => 'bail|required|unique:products|min:4|max:100|string',
               'image' => 'required|mimes:jpj,jpeg,png'
           ]; 
            $request->validate($rules);
            //dd($request);
            //Continues if validation is successful
            $ext = $request->image->extension();
            $filepath = $request->image->storeAs('images', 'photo'.time().'.'.$ext);
            Products::create([
                'name' => $request->name,
                'image' => $filepath
            ]);
            return redirect()->route('admin.products');
       //}else{
           //return redirect()->back()->withInput();
           ///dd('No file selected.');
       //}
    }
    /**
     * Display the specified resource.
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function view(Products $product)
    {
        $admin = auth('admin')->user();
        $this->authorizeForUser($admin, 'view', Products::class); 
        return view('products.view', ['product' => $product ]); 
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Products $product)
    {
        //dd($product->name);
        return view('products.edit', [ 'product' => $product ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = $request->all();
        $rules = [
            'name' => 'bail|required|min:4|max:100|string',
            'image' => 'required|mimes:jpj,jpeg,png'
        ];
        Validator::make($data, $rules)->validate();
        $product = Products::find($id);
        Storage::delete($product->image);
        $product->name = $request->name;
        $ext = $request->image->extension();
        $product->image = $request->image->storeAs('images', 'photo'.''.time().'.'.$ext);
        $product->save();
        return redirect()->route('admin.products.view', ['product' => $product]);
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $product = Products::find($id);
        Storage::delete($product->image);
        Products::find($id)->delete();
        return redirect()->route('admin.products');
    }
}
